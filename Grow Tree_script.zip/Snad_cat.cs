﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snad_cat : MonoBehaviour {

    public Animator anim;
    public GameObject a;
    // Use this for initialization
    void Start()
    {
        anim = GetComponent<Animator>(); // 애니메이션을 받아온다.
        GetComponent<BoxCollider>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        Hand_Move();
    }

    void Hand_Move()
    {
        int direction = 5;// Random.Range(0, 2);
        if (direction == 0)
        {
            Vector3 scale = transform.localScale;
            scale.x = -Mathf.Abs(scale.x);
            transform.localScale = scale;
        }
        else
        {
            Vector3 scale = transform.localScale;
            scale.x = Mathf.Abs(scale.x);
            transform.localScale = scale;

        }
        this.anim.SetBool("R_Auttack", true);
    }

    public void Auttack(float theValue)
    {
       this.anim.SetBool("Auttacking", true);
        
    }

    public void Auttack_collider()
    {
       GetComponent<BoxCollider>().enabled = true;
    }

    void OnTriggerEnter(Collider other) // 충돌처리
    {
        if (other.tag == "Player")
        {
            Destroy(a);
        }
    }

    void cat_delete() // 고양이 지우기
    {
       Destroy(this.gameObject);
    }
}
//애니메이션을 한번하고 정상으로 돌아오기
// 애니메이션 손을할퀴때 충돌처리만들기 -> 충돌후 플레이어삭제후끝