﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FMODUnity;
using FMOD;

public class Sound_Manger : MonoBehaviour {

    private static Sound_Manger instance;
    public static Sound_Manger GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<Sound_Manger>();

            if (instance == null)
            {
                GameObject container = new GameObject("Sound_Manger");

                instance = container.AddComponent<Sound_Manger>();
            }
        }
        return instance;
    }

    [FMODUnity.EventRef] public string eat_leaf; // 코인을먹었을때
    [FMODUnity.EventRef] public string eat_cactus; // 선인장을먹었을대
    [FMODUnity.EventRef] public string button; // 버튼클릭시
    [FMODUnity.EventRef] public string gameover; // 게임오버될때
    [FMODUnity.EventRef] public string fever; // 피버모드돌입시
    [FMODUnity.EventRef] public string one;     // 게임
    [FMODUnity.EventRef] public string two;     // 시작
    [FMODUnity.EventRef] public string three;   // 할때
    [FMODUnity.EventRef] public string strat;   // 소리
    [FMODUnity.EventRef] public string push; // 댕댕이가 나무 뱉을때소리
    [FMODUnity.EventRef] public string fever_push; // 피버때 댕댕이가 나무뱉는소리
    [FMODUnity.EventRef] public string background_Bgm_Game; // 게임플레이중 BGM

    FMOD.Studio.EventInstance BGM_Game;
    FMOD.Studio.EventInstance Fever_Game;
    void Start()
    {
        BGM_Game = FMODUnity.RuntimeManager.CreateInstance(background_Bgm_Game);
        Fever_Game = FMODUnity.RuntimeManager.CreateInstance(fever_push);
    }
    public void Eat_leaf()
    {
        FMODUnity.RuntimeManager.PlayOneShot(eat_leaf);
    }
    public void Eat_cactus()
    {
        FMODUnity.RuntimeManager.PlayOneShot(eat_cactus);
    }
    public void Button()
    {
        FMODUnity.RuntimeManager.PlayOneShot(button);
    }
    public void Gameover()
    {
        FMODUnity.RuntimeManager.PlayOneShot(gameover);
    }

    public void Fever()
    {
        FMODUnity.RuntimeManager.PlayOneShot(fever);
    }

    public void Fever_BGM(int num)
    {
        BGM_Game.setParameterValue("Fever", num);
    }

    public void One()
    {
        FMODUnity.RuntimeManager.PlayOneShot(one);
    }
    public void Two()
    {
        FMODUnity.RuntimeManager.PlayOneShot(two);
    }
    public void Three()
    {
        FMODUnity.RuntimeManager.PlayOneShot(three);
    }
    public void Strat()
    {
        FMODUnity.RuntimeManager.PlayOneShot(strat);
    }
    public void Push()
    {
        FMODUnity.RuntimeManager.PlayOneShot(push);
    }

    public void Fever_push_Start()
    {
        Fever_Game.start();
    }

    public void Fever_push_End()
    {
        Fever_Game.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }

    public void Background_Bgm_Game_Start()
    {
        BGM_Game.start();
    }
    public void BackGround_Bgm_Game_Stop()
    {
        BGM_Game.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }
}
