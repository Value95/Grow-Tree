﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_Manger : MonoBehaviour {

    public GameObject[] Item_List;
    public List<GameObject> Item = new List<GameObject>();

    int Item_pattern = 0;
    int Level = 5;
    float Item_Timer = 2;

	
	
	// Update is called once per frame
	public void Item_Update ()
    {
        Item_Timer -= Time.deltaTime;
        if (Item_Timer < 0)
            Item_Make();
        Item_Move();

    }

    void Item_Make()
    {
        Item_Timer = 5; // 레벨이높아질수록 아이템의떨어지는시간이증가
        
        Item_pattern = Random.Range(0, 8); // 패턴을랜덤으로
        Item.Add(Instantiate(Item_List[Item_pattern], new Vector3(0, 10, 0), transform.rotation) as GameObject);
    }

    void Item_Move()
    {
        for (int i = 0; i < Item.Count; i++)
        {
            Item[i].transform.Translate(Vector3.down * 10 * Time.deltaTime); // 이외에 아이탬을내린다
        }
    }

    public void Item_delete()
    {
        for (int i = 0; i<Item.Count; i++)
            Destroy(Item[i]);

        Item.Clear();
        
    }
}
