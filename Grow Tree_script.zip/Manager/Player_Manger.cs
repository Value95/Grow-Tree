﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Manger : MonoBehaviour {

    public Animator anim;
    public AnimationClip anim_clip;

    [HideInInspector] public float location= 0;  // 터치좌표
    [HideInInspector] public float pos_y; //플레이어의 y좌표
    [HideInInspector] public float pos_x; //플레이어의 x좌표

    [HideInInspector] public bool Player_Hit = false;

    bool move_on = true;
    public float move_off_time = 0;

    private void Start()
    {
        anim = GetComponent<Animator>();
        
        pos_y = 2.98f;
        pos_x = 1.15f;
        transform.position = new Vector3(pos_x, pos_y, 0);
    }

    public void Player_Update()
    {
        transform.Translate(Vector3.down * Game_Manager.GetInstance().Game_Speed * Time.deltaTime);
        pos_y = transform.position.y;
        Player_Move();
        Game_End();
    }

    void Player_Move()
    {
        location = Input.mousePosition.x;

        if (move_on == false)
            move_off_time -= Time.deltaTime;

        if(move_off_time <= 0)
        {
            Game_Manager.GetInstance().Player_MG.anim.SetBool("Snake", false);
            Player_Hit = false;
            move_on = true;
        }

        if (move_on == true)
        {
            if (location > 0 && location < 561)
            {
                Player_Left();
            }
            else if (location > 878 && location < 1450)
            {
                Player_Right();
            }
        }
    }

    void Player_Left() 
    {
        pos_x = -1.27f;
        location = -1;
        transform.position = new Vector3(pos_x, pos_y, 0);
        Vector3 scale = transform.localScale;
        scale.x = -Mathf.Abs(scale.x);
        transform.localScale = scale;
    }

    void Player_Right()
    {
        pos_x = 1.15f;
        location = -1;
        transform.position = new Vector3(pos_x, pos_y, 0);
        Vector3 scale = transform.localScale;
        scale.x = Mathf.Abs(scale.x);
        transform.localScale = scale;
    }

    public void Set_y(float num)
    {
        pos_y = num + 1.36f;
        transform.position = new Vector3(pos_x, pos_y, 0);
    }

    public void Set_y()
    {
        pos_y += 0.81f;
        transform.position = new Vector3(pos_x, pos_y, 0);
    }

    public void Item_Snake()
    {
        move_on = false;
        move_off_time = 1;
    }

    void Game_End()
    {
        if (this.transform.position.y <= -0.5)
            Game_Manager.GetInstance().Game_End();
    }

    public void Plater_reset() // 플레이어 초기화
    {
        Game_Manager.GetInstance().Player_MG.anim.SetBool("Snake", false);
        Player_Hit = false;
        move_on = true;
    }

}
