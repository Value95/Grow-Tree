﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UI_Manger : MonoBehaviour {
    public Text Game_Score;
    public Text End_Score;

    public Slider Fever;
    [HideInInspector] public int score;
    int Level_score;
    public GameObject End_UI;
    // Use this for initialization
    void Start ()
    {
        score = 0;
        Level_score = 0;
    }

    private void Update()
    {
        Game_Score.text = score.ToString() + "M";
        End_Score.text = score.ToString();
        Fever_mode();
        Speed_UP();
    }

    public void Set_Score()
    {
        score += 1;
        Level_score += 1;
    }

    public void Set_Fever()
    {
        Fever.value += 1;
    }

    void Fever_mode() //피버상태 돌입시 모든 아이템 플레이어 변수 초기화
    {
        if(Fever.value == 5)
        {
            Game_Manager.GetInstance().Player_MG.anim.Rebind();
            Sound_Manger.GetInstance().Fever();
            Game_Manager.GetInstance().Fever_start();
            Game_Manager.GetInstance().Player_MG.Plater_reset();
            Game_Manager.GetInstance().Tree_MG.Tree_reset();
            Fever.value = 0;
        }
    }

    public void Game_End()
    {
        if (End_UI.transform.position.x <= 720)
        {
            End_UI.transform.Translate(Vector3.right * 6000 * Time.deltaTime);
        }
        else
            End_UI.transform.position = new Vector3(721, End_UI.transform.position.y, -1);
    }

    void Speed_UP() 
    {
        if(Level_score == 100)
        {
            Game_Manager.GetInstance().Game_Speed += 0.2f;
            Level_score = 0;
        }
    }
}

