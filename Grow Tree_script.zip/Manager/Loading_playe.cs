﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Loading_playe : MonoBehaviour {

    bool IsDone = false;
    AsyncOperation async_operation;
    string Next_View = "main_View";
    int count = 0;
    public GameObject[] Game_story_img; // 게임이미지를 저장한다.

    void Start()
    {
        StartCoroutine(StartLoad(Next_View)); // 여기로 넘어감 게이지가 다차면
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
            count++;
        Next_img();
    }

    public IEnumerator StartLoad(string strSceneName)
    {
        async_operation = Application.LoadLevelAsync(strSceneName);
        async_operation.allowSceneActivation = false;

        if (IsDone == false)
        {
            IsDone = true;

            while (async_operation.progress < 0.9f)
            {
                yield return true;
            }
        }
    }

    void Next_img()
    { 
        if(count == 4)  
        {
            async_operation.allowSceneActivation = true;
        }
        else if (count == 2)
            camera_Scroll();
        else
            Game_story_img[count].SetActive(true);
    }

    void camera_Scroll()
    {
        if (this.transform.position.y >= -1.9)
            this.transform.position = new Vector3(0, this.transform.position.y - 0.2f, -10);
        else
        {
            Game_story_img[count].SetActive(true);
        }
    }

}// 포문을계속 무한루프로돌린다. 지정한위치에가면 무한루프를 false로바꾸어 무한루프를푼다.
// 이미지를 4개의배열에다가 저장 한다.
// 터치를할때 이미지배열을 1씩올린다. 마지막 터치를하면 화면을 넘긴다.