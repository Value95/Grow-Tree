﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// 전반적인 게임상태및 모든게임의 변수를초기화
public class Game_Manager : MonoBehaviour {
    private static Game_Manager instance;
    public static Game_Manager GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<Game_Manager>();

            if (instance == null)
            {
                GameObject container = new GameObject("Game_Manager");

                instance = container.AddComponent<Game_Manager>();
            }
        }
        return instance;
    }

    public Player_Manger Player_MG;
    public Tree_Updata Tree_MG;
    public Scroll_Mapping Bg_MG;
    public UI_Manger UI_MG;
    public Item_Manger Itme_MG;

    public float Game_Speed; // 게임스피드

    public float Fever_Timer = 0;
    public GameObject Fever_img;

    public GameObject[] Start_img;
    [HideInInspector] GameObject Start;
    [HideInInspector] public int start_num = 4;
    [HideInInspector] public float start_Timer = 4;

    //public GameObject End_UI;

    public state condition;
    public enum state { be_ready, start, End, Fever , stop } // 게임상태

	// Use this for initialization
	void Awake () {
        //End_UI.active = false;
        
        condition = state.be_ready;
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
        
        if (condition == state.be_ready) // 게임시작준비
        {
            
            start_Timer -= Time.deltaTime;
            Start_UI((int)start_Timer);
        }
        else if (condition == state.start) // 게임중
        {
            Player_MG.Player_Update();
            Itme_MG.Item_Update();
            Bg_MG.Background_Move();
            Tree_MG.Tree_Update();
            
        }
        else if(condition == state.Fever) // 피버모드
        {
            Fever_Timer -= Time.deltaTime;
            if(Fever_Timer >= 3.1) // 피버 이미지상태
            {
                Fever_img.transform.position = new Vector3(0, 7.6f, 0);
                Sound_Manger.GetInstance().Fever_push_Start();
            }
            else if (Fever_Timer <= 3 && Fever_Timer >= 0.1) // 피버중
            {
                Sound_Manger.GetInstance().Fever_BGM(1);
                Game_Manager.GetInstance().Player_MG.anim.SetBool("Fever", true);
                Fever_img.transform.position = new Vector3(0, 90, 0);// 피벗 이미지 좌표수정
                Tree_MG.Tree_Make();
                Tree_MG.Tree_delete();
                Bg_MG.Background_Move(-0.1f);
            }
            else if (Fever_Timer < 0) // 피버끝
            {
                Sound_Manger.GetInstance().Fever_BGM(0);
                Sound_Manger.GetInstance().Fever_push_End();
                condition = state.start;
                Game_Manager.GetInstance().Player_MG.anim.SetBool("Fever", false);
            }
        }
        else if (condition == state.End) // 게임끝
        {
            Game_Manager.GetInstance().UI_MG.Game_End();
            Game_Manager.GetInstance().Itme_MG.Item_delete();
            Game_Manager.GetInstance().Player_MG.transform.position = new Vector3(50, 50, 0);           
        }
        else if(condition == state.stop)
        {

        }
    }
    public void Start_UI(int Timer)
    {
        if (Timer == 4 && start_num == 4)
        {
            Start = Instantiate(Start_img[0], new Vector3(0, 5.22f, 0), Quaternion.identity)as GameObject;
            Sound_Manger.GetInstance().Three();
            start_num = 3;
        }
        else if (Timer == 3 && start_num == 3)
        {
            Destroy(Start);
            Start = Instantiate(Start_img[1], new Vector3(0, 5.22f, 0), Quaternion.identity) as GameObject;
            Sound_Manger.GetInstance().Two();
            start_num = 2;
        }
        else if (Timer == 2 && start_num == 2)
        {
            Destroy(Start);
            Sound_Manger.GetInstance().One();
            Start = Instantiate(Start_img[2], new Vector3(0, 5.22f, 0), Quaternion.identity) as GameObject;
            start_num = 1;
        }
        else if (Timer == 1 && start_num == 1)
        {
            Destroy(Start);
            Sound_Manger.GetInstance().Strat();
            Start = Instantiate(Start_img[3], new Vector3(0, 6, 0), Quaternion.identity)as GameObject;
            start_num = 0;
        }
        if (Timer == 0 && start_num == 0)
        {
            Destroy(Start);
            Sound_Manger.GetInstance().Background_Bgm_Game_Start();
            Player_MG.location = -1;
            condition = state.start;
        }
    }

    public void Fever_start()
    {
        Itme_MG.Item_delete();
        condition = state.Fever;
        Fever_Timer = 3.7f;
    }

    public void Game_End()
    {
        Sound_Manger.GetInstance().BackGround_Bgm_Game_Stop();
        Sound_Manger.GetInstance().Gameover();
        condition = state.End;
    }

    public void Restaret()
    {
        Sound_Manger.GetInstance().Button();
        SceneManager.LoadScene("Play_View");
    }

    public void MainMenu()
    {
        Sound_Manger.GetInstance().Button();
        SceneManager.LoadScene("main_View");
    }
    public void Quit()
    {
        Application.Quit();
    }
}

