﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scroll_Mapping : MonoBehaviour {

    float ScrollSpeed = 0.1f; //이동속도
    public float Target_Offset = 0;
    BackGround_Down BK;

    void Start()
    {
        BK = GameObject.Find("Background_img").GetComponent<BackGround_Down>();
    }

    public void Background_Move()
    {
        
        Target_Offset += Time.deltaTime* ScrollSpeed;
        GetComponent<MeshRenderer>().material.mainTextureOffset = new Vector2(0 , Target_Offset); // OffsetY의값을바꿈
        BK.BG_Move();
    }

    public void Background_Move(float num) // 맨위에 구름을빠르게 내릴때
    {
        Target_Offset -= num;
        GetComponent<MeshRenderer>().material.mainTextureOffset = new Vector2(0, Target_Offset); // OffsetY의값을바꿈
    }

    
}
