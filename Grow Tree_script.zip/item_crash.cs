﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class item_crash : MonoBehaviour {

    Item_Manger item;

    private void Update()
    {
        item = GameObject.Find("Item_MG").GetComponent<Item_Manger>();
        if (this.transform.position.y <= -10)
        {
            Destroy(this.gameObject);
            item.Item.Remove(gameObject);
        }
    }

    void OnTriggerEnter(Collider other)
    {
       item = GameObject.Find("Item_MG").GetComponent<Item_Manger>();
        if (other.tag == "Player")
        {
            Destroy(this.gameObject);
            item.Item.Remove(gameObject);
            if (this.gameObject.tag == "Coin") // 코인의 충돌
            {
                Sound_Manger.GetInstance().Eat_leaf();
                Game_Manager.GetInstance().UI_MG.Set_Fever();
            }
            else if (this.gameObject.tag == "Scorpion" && Game_Manager.GetInstance().Player_MG.Player_Hit == false) // 전갈의 충돌
            {
                Game_Manager.GetInstance().Player_MG.Player_Hit = true;
                Game_Manager.GetInstance().Player_MG.anim.SetBool("Scorpion", true);
                Game_Manager.GetInstance().Tree_MG.Item_Scorpion();
            }
            else if (this.gameObject.tag == "Snake" && Game_Manager.GetInstance().Player_MG.Player_Hit == false) // 뱀의 충돌
            {
                Game_Manager.GetInstance().Player_MG.Player_Hit = true;
                Game_Manager.GetInstance().Player_MG.anim.SetBool("Snake", true);
                Game_Manager.GetInstance().Player_MG.Item_Snake();
            }
            else if(this.gameObject.tag == "Cactus") // 선인장
            {
                Sound_Manger.GetInstance().Eat_cactus();
                Game_Manager.GetInstance().Game_End();
            }
        }
    }

}