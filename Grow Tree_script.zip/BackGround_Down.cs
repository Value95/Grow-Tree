﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackGround_Down : MonoBehaviour {

	
	
	// Update is called once per frame
	public void BG_Move () {
        this.transform.Translate(Vector3.down * 1 * Time.deltaTime); //Game_Manager.GetInstance().Game_Speed
        //Tree_delete();
    }

    void Tree_delete()    // 나무의 삭제
    {
        if (this.transform.position.y < -3)
        {
            Destroy(this);
        }
    }
}
