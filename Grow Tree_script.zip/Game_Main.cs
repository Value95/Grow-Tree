﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using FMODUnity;
using FMOD;

public class Game_Main : MonoBehaviour {
    [FMODUnity.EventRef] public string background_Bgm_Main;
    FMOD.Studio.EventInstance BGM_Main;
    // Use this for initialization
    void Start () {
        
        BGM_Main = FMODUnity.RuntimeManager.CreateInstance(background_Bgm_Main);
        Background_Bgm_Main_Start();
    }

    public void Change_Button()
    {
        SceneManager.LoadScene("loading_View");
        BackGround_Bgm_Main_Stop();
    }

    public void Background_Bgm_Main_Start()
    {
        BGM_Main.start();
    }
    public void BackGround_Bgm_Main_Stop()
    {
        BGM_Main.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT); ;
    }
}
