﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tree_Updata : MonoBehaviour {
    
    public GameObject[] Tree_img; //게임에 질 나무를저장
    [HideInInspector] public List<GameObject> Tree = new List<GameObject>(); // 게임에 그릴나무 저장

    [HideInInspector] int Tree_Max =10;        // 화면에 뿌려줄수있는최대 나무갯수
    [HideInInspector] public int Tree_count = 0;  //나무의갯수
    [HideInInspector] public float pos_y = 0.16f; //나무의 y좌표

    [HideInInspector] bool Scorpion_on = true;
    [HideInInspector] float Scorpion_off_time = 0;

    [HideInInspector] float location;
    int Tree_Kinds = 0;
    public GameObject Plater_snake_push;
    void Start()
    {
        Tree.Add(Instantiate(Tree_img[6], new Vector3(-0.06f, pos_y, 0), transform.rotation) as GameObject);
        for (; Tree_count < 3; Tree_count++)
        {
            pos_y += 0.81f;
            Tree.Add(Instantiate(Tree_img[0], new Vector3(-0.06f, pos_y, 0), transform.rotation) as GameObject);
        }
        
    }

    public void Tree_Update()
    {

        Scorpion_effect();
        location = Input.mousePosition.x;
        Tree_Move();
        Tree_delete();

        if (Input.GetMouseButtonDown(0) && location >= 562.9387f && location <= 877.0612f && Scorpion_on == true)
        {
            Sound_Manger.GetInstance().Push();
            if (Game_Manager.GetInstance().Player_MG.Player_Hit == false)
            {
                Game_Manager.GetInstance().Player_MG.anim.SetBool("Tree_push", true);
            }
            else
                Plater_snake_push.transform.position = new Vector3(Game_Manager.GetInstance().Player_MG.pos_x, Game_Manager.GetInstance().Player_MG.pos_y, 0);

            Tree_Make();
        }
        else
        {
            Game_Manager.GetInstance().Player_MG.anim.SetBool("Tree_push", false);
            Plater_snake_push.transform.position = new Vector3(999, 999, -1.5f);
        }
        
    }

    public void Tree_Make() // 나무를  생성하는부분
    {
        Tree_Kinds = Tree_percentage();
        if (Tree_Kinds <= 5)

        if (Tree_count < Tree_Max)
        {
                Tree_Make_1();
                Game_Manager.GetInstance().Player_MG.Set_y();
                Tree_count++;   // 나무의 갯수증가
        }
        else if(Tree_count == Tree_Max)
        {
            Tree_Make_1();
            for (int i =0; i < Tree_count+1; i++)   // 나무전부를 한칸씩내리고
            {
            Tree[i].transform.position = new Vector3(-0.06f, Tree[i].transform.position.y - 0.81f, 0);
            }
            Game_Manager.GetInstance().Bg_MG.Background_Move(-0.21f); // 배경도 한칸만큼내리고
            Game_Manager.GetInstance().Player_MG.Set_y(Tree[Tree_count].transform.position.y); // 케릭터의 위치를 맨위나무 위로 다시 잡아주고
            Tree_count++;   // 나무의 갯수증가
        }
        else if(Tree_count == Tree_Max++)
        {
            Tree_Make_1();
            for (int i = 0; i < Tree_count + 1; i++) 
            {
                Tree[i].transform.position = new Vector3(-0.06f, Tree[i].transform.position.y - 0.81f, 0);
            }
            Game_Manager.GetInstance().Bg_MG.Background_Move(-0.21f);
            Game_Manager.GetInstance().Player_MG.Set_y(Tree[Tree_count].transform.position.y);
        }

        Game_Manager.GetInstance().UI_MG.Set_Score(); // 나무 스코어 증가 1
        location = 1;
    }

    void Tree_Make_1()
    {
        pos_y = Tree[Tree_count - 1].transform.position.y;  //나무맨위에 y값을가져와
        Tree.Add(Instantiate(Tree_img[Tree_Kinds], new Vector3(-0.06f, pos_y + 0.81f, 0), transform.rotation) as GameObject);  //그위에 나무를만들고
    }

    public void Tree_delete()    // 나무의 삭제
    { 
       if(Tree[0].transform.position.y < -1.7)
        {
            Tree_count--;
            Destroy(Tree[0]);
            Tree.RemoveAt(0);
        }
    }

    void Tree_Move() // 나무를내려주는부분
    {
        for (int i = 0; i < Tree_count; i++)
            Tree[i].transform.Translate(Vector3.down * Game_Manager.GetInstance().Game_Speed * Time.deltaTime);
    }

    public void Item_Scorpion() // 못누를때 상태
    {
        Scorpion_on = false;
        Scorpion_off_time = 1;
    }

    void Scorpion_effect()
    {
        if (Scorpion_on == false) //움직이지못하는 아이탬을먹었을때
            Scorpion_off_time -= Time.deltaTime;

        if (Scorpion_off_time < 0)
        {
            Scorpion_on = true;
            Game_Manager.GetInstance().Player_MG.Player_Hit = false;
            Game_Manager.GetInstance().Player_MG.anim.SetBool("Scorpion", false);
        }
    }

    public void Tree_reset() //나무를 초기화해주기 위함
    {
        Scorpion_on = true;
        Game_Manager.GetInstance().Player_MG.Player_Hit = false;
        Game_Manager.GetInstance().Player_MG.anim.SetBool("Scorpion", false);
    }

    int Tree_percentage()
    {
        int num = Random.Range(0, 101);
        if(num <= 22.5f )
        {
            num = 0;
        }
        else if(num <= 45.0f)
        {
            num = 1;
        }
        else if(num <= 50.0f)
        {
            num = 2;
        }
        else  if(num <= 55.0f)
        {
            num = 3;
        }
        else if(num <= 77.5f)
        {
            num = 4;
        }
        else if(num <= 100)
        {
            num = 5;
        }
        return num;
    }
}
